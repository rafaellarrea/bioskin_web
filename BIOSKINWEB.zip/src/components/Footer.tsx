import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4">
              <span className="text-[#deb887]">BIO SKIN</span> SALUD Y ESTÉTICA
            </h3>
            <p className="text-gray-400 mb-4">
              Especialistas en tratamientos faciales personalizados de alta tecnología con resultados visibles.
            </p>
		
		{/*redes sociales */}
		<p className="text-gray-400 mb-4">
              Siguenos en nuestras redes:
            </p>

            <div className="flex space-x-4">
              <a href="https://www.facebook.com/share/1BWcENMrip/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#deb887]" aria-label="Facebook">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a href="https://www.instagram.com/salud.bioskin?igsh=dnN2djR6dm94OGFq" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#deb887]" aria-label="Instagram">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </a>
              <a href="https://wa.me/593969890689" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#deb887]" aria-label="WhatsApp">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                </svg>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Servicios</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#services" className="hover:text-[#deb887] transition-colors">Limpieza Facial</a></li>
              <li><a href="#services" className="hover:text-[#deb887] transition-colors">Antiaging</a></li>
              <li><a href="#services" className="hover:text-[#deb887] transition-colors">Antimanchas</a></li>
              <li><a href="#services" className="hover:text-[#deb887] transition-colors">Remoción de Tatuajes</a></li>
              <li><a href="#services" className="hover:text-[#deb887] transition-colors">Hidratación Profunda</a></li>
	      <li><a href="#services" className="hover:text-[#deb887] transition-colors">Exosomas</a></li>
		<li><a href="#services" className="hover:text-[#deb887] transition-colors">Radiofrecuencia</a></li>
		<li><a href="#services" className="hover:text-[#deb887] transition-colors">Y más...</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#home" className="hover:text-[#deb887] transition-colors">Inicio</a></li>
		<li><a href="#products" className="hover:text-[#deb887] transition-colors">Productos</a></li>
              <li><a href="#results" className="hover:text-[#deb887] transition-colors">Resultados</a></li>
              <li><a href="#diagnosis" className="hover:text-[#deb887] transition-colors">Diagnóstico Facial</a></li>
              <li><a href="#about" className="hover:text-[#deb887] transition-colors">Nosotros</a></li>
              <li><a href="#faq" className="hover:text-[#deb887] transition-colors">Preguntas Frecuentes</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contacto</h4>
            <ul className="space-y-2 text-gray-400">
              <li className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-[#deb887] mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
                <span>Cuenca, Ecuador</span>
              </li>
              <li className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-[#deb887] mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                <span>+593 969 890 689</span>
              </li>
              <li className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-[#deb887] mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
                <span>salud.bioskin@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-6 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>&copy; {currentYear} BIO SKIN SALUD Y ESTÉTICA. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;