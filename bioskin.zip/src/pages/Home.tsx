
import React from 'react';

const Home = () => {
  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#fefefe',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      fontSize: '2rem',
      fontWeight: 'bold'
    }}>
      Hola, soy BIOSKIN
    </div>
  );
};

export default Home;
